
/* Number Generator for prime sieve */

/* CHRG 1/7/88 */

#include <helios.h>
#include <stdio.h>
#include <stdlib.h>
#include <posix.h>


#define EndToken 0


int main(int argc, char **argv)

{
	int	val =2;
	int	upper_limit = 1000;
	
	if ( argc == 2 ) {
		upper_limit = atoi(argv[1]);
	}


	do {

		fwrite(&val,sizeof(int),1,stdout);
	}
	while ( val++ < upper_limit );

	/* Terminate sieve */

	val = EndToken;
	fwrite(&val,sizeof(int),1,stdout);

	return(0);
}



