
/* prime sieve filter element */

/* CHRG 1/7/88 */

#include <helios.h>
#include <stdio.h>
#include <nonansi.h>
#include <posix.h>


#define EndToken 0


int main()

{
	FILE	*left  = stdin;
	FILE 	*right = stdout;
	FILE 	*out = fdopen(5, "w");
	int	prime =0, num =0;
	
	
	fread(&prime,sizeof(int),1,left);

	if ( prime != EndToken ) {
		
		/* output prime */
		fprintf(out,"PRIME =%d \n",prime);
	
		/* While NOT EndToken read in numbers  */
		/* and pass on all valeues indivisible */
		/* by prime, to the right stream.      */
		
		fread(&num,sizeof(int),1,left);

		while(num != EndToken) {
		
			if ( num%prime != 0 ) {

				fwrite(&num,sizeof(int),1,right);
	
			}
		
			fread(&num,sizeof(int),1,left);	

		}

		/* Pass on terminating EndToken */	
		fwrite(&num,sizeof(int),1,right);

	}
	
	/* First value read was EndToken */
	else {
		/* Pass on terminating EndToken */
		fwrite(&prime,sizeof(int),1,right);
	}		

	return(0);
}

