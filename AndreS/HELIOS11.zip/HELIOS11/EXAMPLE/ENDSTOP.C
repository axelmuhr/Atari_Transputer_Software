
/* simple EndStop component */

/* CHRG 1/7/88 */

#include <helios.h>
#include <stdio.h>
#include <posix.h>


#define EndToken 0


int main()

{
	int	val;

	fread(&val,sizeof(int),1,stdin);

	while ( val != EndToken ) {

		fread(&val,sizeof(int),1,stdin);	
	}

	return(0);

}



