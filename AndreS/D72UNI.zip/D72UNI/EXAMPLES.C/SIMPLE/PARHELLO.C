#include <stdio.h>
#include <stdlib.h> 
#include <process.h>

void hello(Process *p)
  {
    p = p;
    ProcWait(10000);
    printf("\nWorld\n");
  }

void world(Process *p)
  { 
    p = p;
    printf("\nHello,\n");
  }

int main()
  {
   
    Process *p1, *p2;

    p1 = ProcAlloc(hello,0,0);
    if (p1 == NULL) 
      abort();
    p2 = ProcAlloc(world,0,0);
    if (p1 == NULL) 
      abort();
 
    ProcPar(p1,p2,NULL);

  }

