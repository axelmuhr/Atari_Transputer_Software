#include <channel.h>

int main (int argc, char *argv[], char *envp[],
          Channel *in[], int inlen,
          Channel *out[], int outlen)
{
  int x;
  ChanIn(in[2], &x, sizeof(x));
  x = x * 2;
  ChanOut(out[2], &x, sizeof(x));

  ChanOut(out[2], &x, sizeof(x)); /* synchronise the shutdown */

  return 0;
}

